﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour
{




    public Transform[] spawn;
    public GameObject Player;

    void OnCollisionEnter2D(Collision2D col)
    {

        if (col.gameObject.tag == "Enemy")
        {
            Debug.Log("I Collided Oh No!");
            //this.transform.position = spawnPoint.transform.position;
            Transform spawnPoint = spawn[0];
            Instantiate(Player, spawnPoint.position, spawnPoint.rotation);

        }
    }
}