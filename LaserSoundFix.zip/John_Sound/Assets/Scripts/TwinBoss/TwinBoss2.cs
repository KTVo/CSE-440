﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TwinBoss2 : MonoBehaviour
{

    public float movementSpeed = 10.0f;
    //private Transform target;

    public Transform player;
    public float moveSpeed = 5f;
    private Rigidbody2D rb;


    private Transform target;


    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();

        rb = this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = player.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rb.rotation = angle;
        direction.Normalize();



        if (CalculateDistance() <= 2.0f)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, -1 * movementSpeed * Time.deltaTime);

        }
        else if(CalculateDistance() >= 6.0f)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, movementSpeed * Time.deltaTime);
        }
    }


    private float CalculateDistance()
    {
        if (target)
        {

            float dist = Vector2.Distance(target.position, transform.position);


            return dist;
        }
        else
            return 0;
    }



}
