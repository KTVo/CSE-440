﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TwinBoss2Attack : MonoBehaviour
{
    private int rngWeapon;

    public GameObject bullet;
    public Transform spawnPoint;

    private float timer;

    private float timerChargeLaser;

    public float laserDelay = 1.0f;

    public float shootDelay = 0.5f;

    private float timerDestroyLaser;

    private const int normalShootPercent = 80;

    private LineRenderer lineRenderer;
    public Transform LaserHit;

    public GameObject laserAttack;
    public GameObject laserCharge;



    // Start is called before the first frame update
    void Start()
    {
        RaycastLaserStartUp();
        timer = 0;
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;


        if (timer > shootDelay)
        {

            
        
            rngWeapon = Random.Range(1, 100);

            if (rngWeapon <= normalShootPercent)
            {
                //Standard shooting for TwinBoss2 (Sniper)
                Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
                Debug.Log("Shooting");
            }
            else
            {
                //Laser Beam for TwinBoss2 (Sniper)
                ShootLaser();

                Debug.Log("Laser");
            }

            timer = 0;
        }
    }

    public void ShootLaser()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.up);
        Debug.DrawLine(transform.position, hit.point);

        LaserHit.position = hit.point;
        lineRenderer.SetPosition(0, transform.position);
        lineRenderer.SetPosition(1, LaserHit.position);


        Instantiate(laserAttack, spawnPoint.position, spawnPoint.rotation);





    }

    public void RaycastLaserStartUp()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.enabled = false;
        lineRenderer.useWorldSpace = true;
    }


}
