﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalBossAttack : MonoBehaviour
{
    Rigidbody2D rb;

    private int rngWeapon;

    public GameObject bullet;

    public GameObject pusher;

    public GameObject rockets;

    public Transform spawnPoint;

    private float timer;


    public float laserDelay = 1.0f;

    public float shootDelay = 0.5f;


    public GameObject laserAttack;
    public GameObject laserCharge;


    private LineRenderer lineRenderer;
    public Transform LaserHit;

    [Range(1, 100)] public float LaserDamage = 50.0f;
    // Start is called before the first frame update
    void Start()
    {

        timer = 0;
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.enabled = false;
        lineRenderer.useWorldSpace = true;
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;


        if (timer > shootDelay)
        {

            rngWeapon = Random.Range(1, 100);
 
            if (rngWeapon <= 64)
            {
                //Standard shooting for TwinBoss2 (Sniper)
                Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
                lineRenderer.enabled = false;

            }
            else if (rngWeapon >= 65 && rngWeapon <= 80)
            {
                //Fires tracer bombs
                Instantiate(rockets, spawnPoint.position, spawnPoint.rotation);
                lineRenderer.enabled = false;

            }
            else
            {
                //Laser Beam for TwinBoss2 (Sniper)
                RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.up);
                Debug.DrawLine(transform.position, hit.point);

                LaserHit.position = hit.point;
                lineRenderer.SetPosition(0, transform.position);
                lineRenderer.SetPosition(1, LaserHit.position);

                lineRenderer.enabled = true;

                ShootLaser();

                if(lineRenderer.enabled == true)
                    rb.rotation = 0;

                if(timer > 2)
                    lineRenderer.enabled = false;

            }
            //Add a melee attack after this
            //Add push back after this

            timer = 0;
        }
    }

    void ShootLaser()
    {
        RaycastHit2D hit = Physics2D.Raycast(LaserHit.position, LaserHit.right);

        if (hit)
        {
            Health enemyHealth = hit.transform.GetComponent<Health>();
            if (enemyHealth != null)
            {
                enemyHealth.DamageHealth(20);
                Debug.Log("Haha! I Hit you!");
            }
        }
    }

}
