﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointManager : MonoBehaviour
{
    private static CheckPointManager instance;
    public Vector2 currentPosition;


    

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void Awake()
    {
        //Respawns player at the position of their death
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);    //Makes it so object doesn't destroy itself/reset info btw scenes
        }
        else
        {
            Destroy(gameObject);    //Destroys player object after respawn

            
        }
        
    }
}
