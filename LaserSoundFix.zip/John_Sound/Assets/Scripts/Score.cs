﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Score : MonoBehaviour
{
    //When last enemy dies of a wave spawn in another wave

    //@ 212 wave 1
    //@ 190 wave 2

    //@ 100 Boss comes in
    //      Kill boss @ 80 second remaining = 80 * timeScoreMultiplier = Time Score

    /*
     *  if we kill wave 1 at 200, then wave 2 will spawn at 200
     *      then Boss will spawn at 110
     *      timeScore = 90
     */

    //Have everytime enemy destroyed increments (killCounter)

    private const int totalMissionTime = 215;
    
    private int currentTimeLeft = totalMissionTime;

    private int killCounter = 0;    //Counts whenever enemy gets shot at

    private int missCounter = 0;   //Counts whenever enemy flies out and gets destroyed

    private const int timeScoreMultiplier = 1000;   //gets multiplied to time we have left

    private int timeScore = 0; //stores the score dealing with time multiplier

    private int totalScore = 0; //Stores the total score

    // Start is called before the first frame update

    private void Awake()
    {
        currentTimeLeft = totalMissionTime;
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }



    public void IncRemainingTime()
    {

    }

    public void SetTimeRemaining(float timeRemaining)
    {
        timeScore += (int)timeRemaining * timeScoreMultiplier;

        totalScore += timeScore;
    }

    public void IncKillCounter()
    {
        killCounter++;
    }

    public void IncMissCounter()
    {
        missCounter++;
    }

    public int GetTimeScore()
    {
        return this.timeScore;
    }

    public int GetTotalScore()
    {
        return this.totalScore;
    }


}
