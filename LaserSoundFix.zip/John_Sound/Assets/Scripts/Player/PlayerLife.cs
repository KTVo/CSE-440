﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  //Use for reloading game as long as player has some life left

public class PlayerLife : MonoBehaviour
{
    public int lifeCount = 3;
    protected bool playerIsDead = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void LifeCheck()
    {
        if (lifeCount > 0)
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        else
        {
            Debug.Log("Game Over.");
        }
    }


    protected void LoseLife()
    {
        lifeCount--;
        Debug.Log("Lost a Life! Life Left: " + GetLifeCount());
        LifeCheck();

    }

    protected void GainLife()
    {
        lifeCount++;
        Debug.Log("Gained a Life! Life Left: " + GetLifeCount());
    }

    public int GetLifeCount()
    {
        return lifeCount;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "PickupLife")
        {
            GainLife();
        }
        

        Destroy(collision.gameObject);
    }
}
