﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public Camera mainCamera;
    Vector3 cameraInitialPosition;
    public float shakeMagnitude = 0.05f, shakelength = 0.5f;

    private float laserTimer;
    private float laserDelayTimer;

    private int numBomb = 3;

    private int bulletDmg = 20;

    private float timerWingman;

    public GameObject laserShot;
    public GameObject bullet;
    //These bullet activates when Multishot pickup is true
    public GameObject bulletSP1;
    public GameObject bulletSP2;
    public GameObject bomb;

    public Transform spawnPoint;
    public Transform spawnPointSP1;
    public Transform spawnPointSP2;
    public Transform spawnPointLaser;

    public Transform spawnBomb;




    private bool isWingman = false;
    private bool isLaser = false;

    private LineRenderer lineRenderer;
    public Transform LaserHit;

    [Range(1, 100)] public float LaserDamage = 50.0f;

    // Start is called before the first frame update
    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.enabled = false;
        lineRenderer.useWorldSpace = true;
    }



    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space) && !isWingman)
        {
            //Standard shooting
            Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
            AudioManager.instance.PlaySFX(0);
        }
        else if (Input.GetKeyDown(KeyCode.Space) && isWingman)
        {
            timerWingman += Time.deltaTime;

            //Shoots Wingman
            Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
            Instantiate(bulletSP1, spawnPointSP1.position, spawnPointSP1.rotation);
            Instantiate(bulletSP2, spawnPointSP2.position, spawnPointSP2.rotation);

            if (timerWingman > 1)
            {
                isWingman = false;
            }

            if (isWingman == false)
            {
                timerWingman = 0.0f;
            }

        }
        else if (Input.GetKey(KeyCode.Z) && true)
        {
            laserTimer += Time.deltaTime;
            laserDelayTimer += Time.deltaTime;

            if (Input.GetKey(KeyCode.Z) && (laserDelayTimer > 0.1))
            {
                Instantiate(laserShot, spawnPointLaser.position, spawnPointLaser.rotation);
                AudioManager.instance.PlaySFX(1);
                laserDelayTimer = 0.0f;
            }

            if (laserTimer > 10)
                isLaser = false;

            /*
             RaycastHit2D hit = Physics2D.Raycast(startLaser.position, startLaser.up);
             Debug.DrawLine(startLaser.position, hit.point);

             LaserHit.position = hit.point;
             lineRenderer.SetPosition(0, startLaser.position);
             lineRenderer.SetPosition(1, LaserHit.position);

             if (Input.GetKey(KeyCode.Z))
             {
                 Debug.Log("HIIIIIII!! LASER.");

                 lineRenderer.enabled = true;

                 ShootLaser();
             }
             else
             {
                 lineRenderer.enabled = false;

                 isLaser = false;
             }
         }
         */
        }
        else if (Input.GetKeyDown(KeyCode.X) && (numBomb > 0))
        {
            AudioManager.instance.PlaySFX(3);

            Instantiate(bomb, spawnBomb.position, spawnBomb.rotation);

            numBomb--;

            Debug.Log("Number of Bombs Left: " + numBomb);
            

            ShakeIT();

        }

    }

    void ShootLaser()
    {
        RaycastHit2D hit = Physics2D.Raycast(LaserHit.position, LaserHit.right);

        if (hit)
        {
            Health enemyHealth = hit.transform.GetComponent<Health>();
            if (enemyHealth != null)
            {
                enemyHealth.DamageHealth(bulletDmg);
                Debug.Log("Haha! I Hit you!");
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "PickupLaser")
        {
            isLaser = true;
            Destroy(collision.gameObject);
            laserTimer = 0;
            AudioManager.instance.PlaySFX(2);
        }
        else if (collision.gameObject.tag == "PickupWingman")
        {
            isWingman = true;
            Destroy(collision.gameObject);
            AudioManager.instance.PlaySFX(2);
        }
        else if (collision.gameObject.tag == "PickupBomb")
        {
            numBomb++;
            Destroy(collision.gameObject);
            AudioManager.instance.PlaySFX(2);

        }


    }



    public void ShakeIT()
    {
        cameraInitialPosition = mainCamera.transform.position;
        InvokeRepeating("StartCameraShaking", 0f, 0.005f);
        Invoke("StopCameraShaking", shakelength);
    }

    void StartCameraShaking()
    {
        float cameraShakingOffsetX = Random.value * shakeMagnitude * 2 - shakeMagnitude;
        float cameraShakingOffsetY = Random.value * shakeMagnitude * 2 - shakeMagnitude;
        Vector3 cameraIntermadiatePosition = mainCamera.transform.position;
        cameraIntermadiatePosition.x += cameraShakingOffsetX;
        cameraIntermadiatePosition.y += cameraShakingOffsetY;
        mainCamera.transform.position = cameraIntermadiatePosition;

    }

    void StopCameraShaking()
    {
        CancelInvoke("StartCameraShaking");
        mainCamera.transform.position = cameraInitialPosition;
    }






}
