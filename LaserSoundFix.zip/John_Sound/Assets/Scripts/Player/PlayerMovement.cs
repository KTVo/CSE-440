﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    bool controlIsNormal = true;   //States if players controls are altered

    [Header("Keyboard Input: ")]
    public KeyCode moveLeft = KeyCode.LeftArrow;
    public KeyCode moveRight = KeyCode.RightArrow;
    public KeyCode moveUp = KeyCode.UpArrow;
    public KeyCode moveDown = KeyCode.DownArrow;

    public KeyCode shoot = KeyCode.Space;

    [Header("Horizontal Speed Settings: ")]
    public float speedMultiplier = 5.0f;    // Play around with this setting to optimize the right speed for the player in the inspector.



    private Rigidbody2D rb;                 // Used to apply forces with a 2D gameobject

    /// <summary>
    /// Start is called before the first frame update
    /// </summary>
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();   // Initialize the Rigidbody2D object with this gameobject's Rigidbody2D component that is attached to it in the inspector.
    }

    /// <summary>
    /// Fixed Update is called once per fixed frame.
    /// Use physical behaviors (or anything involving the rigidbody) in this function.
    /// </summary>
    private void FixedUpdate()
    {

    }

    /// <summary>
    /// Update is called once per frame
    /// </summary>
    void Update()
    {
        // Create a local variable to store the next movement calculation.
        PlayerMovementControls(controlIsNormal);

        //Keeps the player looking straight at all times
        float angle = Mathf.Atan2(0, 0) * Mathf.Rad2Deg;
        rb.rotation = angle;

    }

    public void PlayerMovementControls(bool isNormal)
    {
        Vector2 newMovement;

        //Checks if controls are normal
        //if isNormal is false, then controls are reversed
        //This is used for Boss' effect
        if (isNormal)
        {
            if (Input.GetKey(moveLeft))                                                                         // Check if moveLeft key is pressed.
            {
                newMovement = new Vector2(rb.position.x - (Time.deltaTime * speedMultiplier), rb.position.y);   // Move the player along the x-axis using a speed multiplier in the left direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveRight))                                                                        // Check if moveRight key is pressed.
            {
                newMovement = new Vector2(rb.position.x + (Time.deltaTime * speedMultiplier), rb.position.y);   // Move the player along the x-axis using a speed multiplier in the right direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveUp))                                                                         // Check if moveLeft key is pressed.
            {
                newMovement = new Vector2(rb.position.x, rb.position.y + (Time.deltaTime * speedMultiplier));   // Move the player along the x-axis using a speed multiplier in the left direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveDown))                                                                        // Check if moveRight key is pressed.
            {
                newMovement = new Vector2(rb.position.x, rb.position.y - (Time.deltaTime * speedMultiplier));   // Move the player along the x-axis using a speed multiplier in the right direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
        }
        else
        {
            if (Input.GetKey(moveRight))                                                                         // Check if moveLeft key is pressed.
            {
                newMovement = new Vector2(rb.position.x - (Time.deltaTime * speedMultiplier), rb.position.y);   // Move the player along the x-axis using a speed multiplier in the left direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveLeft))                                                                        // Check if moveRight key is pressed.
            {
                newMovement = new Vector2(rb.position.x + (Time.deltaTime * speedMultiplier), rb.position.y);   // Move the player along the x-axis using a speed multiplier in the right direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveDown))                                                                         // Check if moveLeft key is pressed.
            {
                newMovement = new Vector2(rb.position.x, rb.position.y + (Time.deltaTime * speedMultiplier));   // Move the player along the x-axis using a speed multiplier in the left direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
            if (Input.GetKey(moveUp))                                                                        // Check if moveRight key is pressed.
            {
                newMovement = new Vector2(rb.position.x, rb.position.y - (Time.deltaTime * speedMultiplier));   // Move the player along the x-axis using a speed multiplier in the right direction.
                rb.position = newMovement;                                                                      // Set the rigidbody position to the newMovement position that was just calculated.
            }
        }
    }
}
