﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAutoRotate : MonoBehaviour
{
    public Transform player;
    private Rigidbody2D rb;
    float angle;
    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        Vector3 direction = player.position - transform.position;
        angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rb.rotation = angle;
        direction.Normalize();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //float angle = Mathf.Atan2(-GameObject.FindGameObjectWithTag("Player").transform.position.y, -GameObject.FindGameObjectWithTag("Player").transform.position.x) * Mathf.Rad2Deg;

        transform.localRotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }
}
