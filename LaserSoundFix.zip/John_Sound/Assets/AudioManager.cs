﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AudioManager : MonoBehaviour
{
private int clipSFX = 0;
    private int clipBGM = 0;

    [Range(0, 2)] private int modes = 2;
    public Text sfxTrackName;
    public Text bgmTrackName;

    public static AudioManager instance;

    public AudioClip[] sfxClips;
    public AudioSource sfxAudioSource;
    [Range(0, 1)] public float sfxVolume = 1.0f;


    public AudioClip[] bgmClips;
    public AudioSource bgmAudioSource;
    [Range(0, 1)] public float bgmVolume = 1.0f;

    public Slider sfxSlid;
    public Slider bgmSlid;

    [Range(0, 1)] private float savedBgmVol = 1.0f;
    [Range(0, 1)] private float savedSfxVol = 1.0f;
    private int savedSFXClip = 0;
    private int savedBGMClip = 0;

    

    private void Awake()
    {
        instance = this;

    }
    
    




    // Start is called before the first frame update
    
    
    void Start()
    {
        bgmTrackName.text = clipBGM.ToString();
        sfxTrackName.text = clipSFX.ToString();

        PlayBGM(0);
    }

    // Update is called once per frame
    void Update()
    {
        
        sfxAudioSource.volume = sfxVolume;
        bgmAudioSource.volume = bgmVolume;
    }

    public void PlaySFX(int clip)
    {
        clip = clipSFX;
        sfxAudioSource.PlayOneShot(sfxClips[clip]);
    }

    public void PlayBGM(int clip)
    {
        bgmAudioSource.Stop();
        bgmAudioSource.clip = bgmClips[clip];
        bgmAudioSource.Play();
    }


    public void incrClipSFX()
    {
        if (clipSFX < 3)
        {
            ++clipSFX;

            sfxTrackName.text = clipSFX.ToString();

            Debug.Log("SFX Track = " + clipSFX);
        }
        else
            Debug.Log("Error: You've exceeded the preset range for SFX clips.");
    }

    public void decrClipSFX()
    {
        if (clipSFX > 0)
        {
            --clipSFX;

            sfxTrackName.text = clipSFX.ToString();

            Debug.Log("SFX Track = " + clipSFX);
        }
        else
            Debug.Log("Error: You've exceeded the preset range for SFX clips.");


    }


    public void runPlaySFX()
    {
        sfxAudioSource.Stop();
        sfxAudioSource.clip = sfxClips[clipSFX];
        sfxAudioSource.Play();
    }


    public void incrClipBGM()
    {
        if (clipBGM < 0)
        {
            ++clipBGM;

            bgmTrackName.text = clipBGM.ToString();

            Debug.Log("BGM Track = " + clipBGM);
        }
        else
            Debug.Log("Error: You've exceeded the preset range for BGM clips.");

    }

    public void decrClipBGM()
    {
        if (clipBGM > 0)
        {
            --clipBGM;

            bgmTrackName.text = clipBGM.ToString();

            Debug.Log("BGM Track = " + clipBGM);
        }
        else
            Debug.Log("Error: You've exceeded the preset range for BGM clips.");
    }



    public void runPlayBGM()
    {
        instance.PlayBGM(clipBGM); 
    }

    public void sfxSliderAdjust()
    {
        sfxVolume = sfxSlid.value;
    }

    public void bgmSliderAdjust()
    {
        bgmVolume = bgmSlid.value;
    }


    public void DefaultButton()
    {
        clipSFX = 0;
        clipBGM = 0;

        sfxVolume = 1f;
        bgmVolume = 1.0f;

        savedBgmVol = bgmVolume;
        savedSfxVol = sfxVolume;
        savedSFXClip = clipSFX;
        savedBGMClip = clipBGM;

        sfxTrackName.text = clipSFX.ToString();
        bgmTrackName.text = clipBGM.ToString();

        modes = 0;

        Debug.Log("Default Settings Applied: SFX Clip = 0, SFX Volume = 1 BGM Clip = 1, BGM Volume = 1.");
    }

    public void SavedButton()
    {
        savedBgmVol = bgmVolume;
        savedSfxVol = sfxVolume;
        savedSFXClip = clipSFX;
        savedBGMClip = clipBGM;

        sfxTrackName.text = clipSFX.ToString();
        bgmTrackName.text = clipBGM.ToString();

        bgmVolume = savedBgmVol;
        sfxVolume = savedSfxVol;
        clipSFX = savedSFXClip;
        clipBGM = savedBGMClip;

        modes = 1;
        Debug.Log("Default Settings Applied: SFX Clip = " + savedSFXClip + ", SFX Volume = " + savedSfxVol + "BGM Clip = " + savedBGMClip + ", BGM Volume = " + savedBgmVol + ".");
    }


    public void CurrentSettings()
    {
        bgmVolume = savedBgmVol;
        sfxVolume = savedSfxVol;
        clipSFX = savedSFXClip;
        clipBGM = savedBGMClip;
    }


    
    public void IsSaved()
    {

        if (modes == 0)
        {
            DefaultButton();

        }
        else if (modes == 1)
        {
            SavedButton();

        }
        else if (modes == 2)
        {
            CurrentSettings();
        }

        modes = 2;

        sfxTrackName.text = clipSFX.ToString();
        bgmTrackName.text = clipBGM.ToString();
    }
}

