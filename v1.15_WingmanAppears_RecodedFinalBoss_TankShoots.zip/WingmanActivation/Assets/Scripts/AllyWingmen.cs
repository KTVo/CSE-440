﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllyWingmen : MonoBehaviour
{
    //public GameObject Player;
    public float movementSpeed = 10;
   
    private Transform target;
 

 

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
       

        if(distWingmanToPlayer() >= 2)
            transform.position = Vector2.MoveTowards(transform.position, target.position, movementSpeed * Time.deltaTime);

    }

    private float distWingmanToPlayer()
    {
        if (target)
        {

            float dist = Vector2.Distance(target.position, transform.position);
            

            return dist;
        }
        else
            return 0;
    }
}
