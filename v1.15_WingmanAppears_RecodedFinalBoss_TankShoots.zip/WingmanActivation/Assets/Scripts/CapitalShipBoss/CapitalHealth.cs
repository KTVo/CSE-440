﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CapitalHealth : MonoBehaviour
{
    [Header("Health Settings:")]
    [Range(100, 200)] public float maxHealthCapital = 100.0f;
    [Range(100, 200)] public float maxHealthTurretFollowFrontLeft = 100.0f;
    [Range(100, 200)] public float maxHealthTurretFollowMiddle = 100.0f;
    [Range(100, 200)] public float maxHealthTurretFollowFrontRight = 100.0f;
    [Range(100, 200)] public float maxHealthTurretBackLeft = 100.0f;
    [Range(100, 200)] public float maxHealthTurretBackRight = 100.0f;
    [Range(100, 200)] public float maxHealthTurretBackMiddle = 100.0f;

    public bool destroyOnDeath = true;
    private float currentHealthCapital;
    private float currentHealthTurretFollowFrontLeft;
    private float currentHealthTurretFollowMiddle;
    private float currentHealthTurretFollowFrontRight;
    private float currentHealthTurretBackLeft;
    private float currentHealthTurretBackRight;
    private float currentHealthTurretBackMiddle;

    private bool isDead_TurretFollowFrontLeft = false;
    private bool isDead_TurretFollowMiddle = false;
    private bool isDead_TurretFollowFrontRight = false;
    private bool isDead_TurretBackLeft = false;
    private bool isDead_TurretBackRight = false;
    private bool isDead_TurretBackMiddle = false;

    public Collision2D FrontLeft, FrontMiddle, FrontRight, BackLeft, BackMiddle, BackRight;




    [Header("Debug Settings:")]
    public bool debugComponent = false;

    // Start is called before the first frame update
    void Start()
    {

     

        currentHealthTurretFollowFrontLeft = maxHealthTurretFollowFrontLeft;
        currentHealthTurretFollowMiddle = maxHealthTurretFollowMiddle;
        currentHealthTurretFollowFrontRight = maxHealthTurretFollowFrontRight;
        currentHealthTurretBackLeft = maxHealthTurretBackLeft;
        currentHealthTurretBackRight = maxHealthTurretBackRight;
        currentHealthTurretBackMiddle = maxHealthTurretBackMiddle;


        currentHealthCapital = maxHealthCapital;    // Initialize current health with max health.

        if (debugComponent)
            Debug.Log(gameObject.name + " Health: " + currentHealthCapital + "/" + maxHealthCapital);
    }

    // Update is called once per frame
    void Update()
    {



        if (isDead_TurretFollowFrontLeft)
        { 
        
        }

        if (isDead_TurretFollowMiddle)
        { 
        
        }

        if(isDead_TurretFollowFrontRight)
        {
    
        }

        if(isDead_TurretBackLeft)
        {
    
        }

        if(isDead_TurretBackRight)
        {
    
        }

        if(isDead_TurretBackMiddle)
        {
    
        }




        //Check Death for Front LEFT Turret that follows player
        if (currentHealthTurretFollowFrontLeft <= 0)
        {
            isDead_TurretFollowFrontLeft = true;
        }
        else if (currentHealthCapital >= maxHealthTurretFollowFrontLeft)
        {
            currentHealthTurretFollowFrontLeft = maxHealthTurretFollowFrontLeft;

        }

        //Check Death for Front MIDDLE Turret that follows player
        if (currentHealthTurretFollowMiddle <= 0)
        {
            isDead_TurretFollowMiddle = true;
        }
        else if (currentHealthCapital >= maxHealthTurretFollowMiddle)
        {
            currentHealthTurretFollowMiddle = maxHealthTurretFollowMiddle;
        }

        //Check Death for Front RIGHT Turret that follows player
        if (currentHealthTurretFollowFrontRight <= 0)
        {
            isDead_TurretFollowFrontRight = true;
        }
        else if (currentHealthCapital >= maxHealthTurretFollowFrontRight)
        {
            currentHealthTurretFollowFrontRight = maxHealthTurretFollowFrontRight;
        }

        //Check Death for BACK LEFT Turret that follows player
        if (currentHealthTurretBackLeft <= 0)
        {
            isDead_TurretBackLeft = true;
        }
        else if (currentHealthCapital >= maxHealthTurretBackLeft)
        {
            currentHealthTurretBackLeft = maxHealthTurretBackLeft;
        }

        //Check Death for BACK RIGHT Turret that follows player
        if (currentHealthTurretBackRight <= 0)
        {
            isDead_TurretBackRight = true;
        }
        else if (currentHealthCapital >= maxHealthTurretBackRight)
        {
            currentHealthTurretBackRight = maxHealthTurretBackRight;
        }

        //Check Death for BACK MIDDLE Turret that follows player
        if (currentHealthTurretBackMiddle <= 0)
        {
            isDead_TurretBackMiddle = true;
        }
        else if (currentHealthCapital >= maxHealthTurretBackMiddle)
        {
            currentHealthTurretBackMiddle = maxHealthTurretBackMiddle;
        }



        if (isDead_TurretFollowFrontLeft && isDead_TurretFollowMiddle &&
            isDead_TurretFollowFrontRight && isDead_TurretBackLeft && isDead_TurretBackRight && isDead_TurretBackMiddle)
        {
            // Check health levels
            if (currentHealthCapital <= 0)
            {

                Destroy(gameObject);    // You can set a time to destroy for room to play a death animation.  Destroy(gameObject, 2.5f);

            }
            else if (currentHealthCapital >= maxHealthCapital)
            {
                currentHealthCapital = maxHealthCapital;
            }
        }
    }

    /// <summary>
    /// A method for healing gameobject with Health component.
    /// </summary>
    /// <param name="heal"></param>
    public void HealHealth(float heal)
    {
        currentHealthCapital += heal;

        if (debugComponent)
            Debug.Log(gameObject.name + " Health: " + currentHealthCapital + "/" + maxHealthCapital);
    }


    /// <summary>
    /// A method for damaging gameobject with Health component.
    /// </summary>
    /// <param name="damage"></param>
    public void DamageHealth(float damage)
    {



        if (isDead_TurretFollowFrontLeft && isDead_TurretFollowMiddle &&
            isDead_TurretFollowFrontRight && isDead_TurretBackLeft && isDead_TurretBackRight && isDead_TurretBackMiddle)
        {
            currentHealthCapital -= damage;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthCapital + "/" + maxHealthCapital);
        }
    }

    private void OnCollisionEnter2D()
    {
        const int dmgToTurret = 10;
        
        if (FrontLeft.gameObject.tag == "PlayerBullet")
        {
            currentHealthTurretFollowFrontLeft -= dmgToTurret;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthTurretFollowFrontLeft + "/" + maxHealthCapital);
        }

        if (FrontMiddle.gameObject.tag == "PlayerBullet")
        {
            currentHealthTurretFollowMiddle -= dmgToTurret;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthTurretFollowMiddle + "/" + maxHealthCapital);
        }

        if (FrontRight.gameObject.tag == "PlayerBullet")
        {
            currentHealthTurretFollowFrontRight -= dmgToTurret;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthTurretFollowFrontRight + "/" + maxHealthCapital);
        }

        if (BackMiddle.gameObject.tag == "PlayerBullet")
        {
            currentHealthTurretBackMiddle -= dmgToTurret;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthTurretBackMiddle + "/" + maxHealthCapital);
        }

        if (BackRight.gameObject.tag == "PlayerBullet")
        {
            currentHealthTurretBackRight -= dmgToTurret;

            if (debugComponent)
                Debug.Log(gameObject.name + " Health: " + currentHealthTurretBackRight + "/" + maxHealthCapital);
        }


    }

}