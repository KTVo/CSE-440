﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CapitalBackTurretRotate : MonoBehaviour
{
    public float movementSpeed = 10.0f;
    //private Transform target;

    public Transform player;
    public float moveSpeed = 5f;
    private Rigidbody2D rb;


    

    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
        if (GameObject.FindGameObjectWithTag("Player") != null)
        {
            player = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null)
        {

            Vector3 direction = player.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            rb.rotation = angle;
            direction.Normalize();

            rb.velocity = Vector3.zero;
        }
    }
}