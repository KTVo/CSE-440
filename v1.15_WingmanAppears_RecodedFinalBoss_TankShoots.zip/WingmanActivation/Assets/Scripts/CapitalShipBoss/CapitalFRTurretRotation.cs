﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CapitalFRTurretRotation : MonoBehaviour
{
    private const int rotateSpeed = 5;
    private float timeLeft = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timeLeft += Time.deltaTime;

        if (Mathf.Floor(timeLeft) <= 2)
        {
            transform.Rotate(0, 0, 1 * rotateSpeed * Time.deltaTime);   //rotates in degrees per second

            Debug.Log("First = " + timeLeft);
           
        }
        else if(Mathf.Floor(timeLeft) >= 3)
        {
            transform.Rotate(0, 0, -1 * rotateSpeed * Time.deltaTime);   //rotates in degrees per second
            Debug.Log("Second = " + timeLeft);
            if(Mathf.Floor(timeLeft) == 6)
                timeLeft = 0.0f;
        }

    }
}
