﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultishotRotate : MonoBehaviour
{
    private int rndNum = 3;
    private bool rotateCW = true;
    private int countHalfRotation = 500;

    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.rotation = 0.0f;
    }

    // Update is called once per frame
    void FixedUpdate()
    {

        //Only run when rotation cycle is completed or non-rotation mode is ON
        if (countHalfRotation >= 2 || rndNum > 3)
        {
            rndNum = Random.Range(1, 500);  //RNG for rotation mode or not
            countHalfRotation = 0;
            rb.rotation = 0.0f; //Resets the rotation
        }

        //Rotate if RNG is <=3
        if(rndNum <= 3)
            //Rotates from 45 degrees to -45 degrees then stops
            if (rotateCW == false)
            {
                rb.rotation -= 1.0f;

                if (Mathf.CeilToInt(rb.rotation) == -45)
                {
                    rotateCW = true;
                    countHalfRotation++;
                }
            }
            else
            {
                rb.rotation += 1.0f;
                if (Mathf.CeilToInt(rb.rotation) == 45)
                {
                    rotateCW = false;
                    countHalfRotation++;
                }
            }


    }
    
}
