﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultishotAttack : MonoBehaviour
{
    public GameObject bullet1;
    public GameObject bullet2;
    public GameObject bullet3;
    public GameObject bullet4;
    public GameObject bullet5;
    public GameObject bullet6;
    public GameObject bullet7;
    public GameObject bullet8;
    public GameObject bullet9;

    public Transform spawnPoint1;
    public Transform spawnPoint2;
    public Transform spawnPoint3;
    public Transform spawnPoint4;
    public Transform spawnPoint5;
    public Transform spawnPoint6;
    public Transform spawnPoint7;
    public Transform spawnPoint8;
    public Transform spawnPoint9;

    private float timer = 0.0f;

    public float shootDelay = 0.2f;

    private int typesOfShot = 1;

    private int selectWeapon = 0;

    private bool shotAll = false;

    private int count = 0;

    private int shootInnerOuterCnt = 0;

    // Start is called before the first frame update
    void Start()
    {
        //StartCoroutine(EnemyShoot());
        timer = 0;
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;


        if ((timer > shootDelay)) //the true-statement bypasses the shooting timer to find the result we want
        {
            if(typesOfShot >= 1 && typesOfShot <= 3)
                typesOfShot = Random.Range(1, 9);

            if(typesOfShot > 6)
                typesOfShot = Random.Range(1, 3);

            Debug.Log("typesOfShot = " + typesOfShot);

            if (typesOfShot != 4 && typesOfShot != 5 && typesOfShot !=6)
                MultishotPattern(typesOfShot);
            else if (typesOfShot == 4 && typesOfShot == 5)
            {

                if (count <= 9)
                {
                    MultishotPattern(typesOfShot);
                    count++;
                }
                else
                {
                    count = 0;
                    typesOfShot = 1;
                }


            }
            else
            {
                if (shootInnerOuterCnt <= 10)
                {
                    MultishotPattern(6);
                }
                else
                {
                    shootInnerOuterCnt = 0;
                    typesOfShot = 1;
                }
            }
            timer = 0;
        }

    }


    private void MultishotPattern(int select)
    {
        switch (select)
        {
            //All Guns
            case 1:
                {
                    Instantiate(bullet1, spawnPoint1.position, spawnPoint1.rotation);
                    Instantiate(bullet2, spawnPoint2.position, spawnPoint2.rotation);
                    Instantiate(bullet3, spawnPoint3.position, spawnPoint3.rotation);
                    Instantiate(bullet4, spawnPoint4.position, spawnPoint4.rotation);
                    Instantiate(bullet5, spawnPoint5.position, spawnPoint5.rotation);
                    Instantiate(bullet6, spawnPoint6.position, spawnPoint6.rotation);
                    Instantiate(bullet7, spawnPoint7.position, spawnPoint7.rotation);
                    Instantiate(bullet8, spawnPoint8.position, spawnPoint8.rotation);
                    Instantiate(bullet9, spawnPoint9.position, spawnPoint9.rotation);
                    break;
                }
            //Even Guns
             case 2: 
                {
                    Instantiate(bullet2, spawnPoint2.position, spawnPoint2.rotation);
                    Instantiate(bullet4, spawnPoint4.position, spawnPoint4.rotation);
                    Instantiate(bullet6, spawnPoint6.position, spawnPoint6.rotation);
                    Instantiate(bullet8, spawnPoint8.position, spawnPoint8.rotation);
                    break;
                }

            //Odd Guns
            case 3:
                {
                    Instantiate(bullet1, spawnPoint1.position, spawnPoint1.rotation);
                    Instantiate(bullet3, spawnPoint3.position, spawnPoint3.rotation);
                    Instantiate(bullet5, spawnPoint5.position, spawnPoint5.rotation);
                    Instantiate(bullet7, spawnPoint7.position, spawnPoint7.rotation);
                    Instantiate(bullet9, spawnPoint9.position, spawnPoint9.rotation);
                    break;
                }
            //Left-to-Right
            case 4:
                {

                    SelectShots(selectWeapon);

                    selectWeapon++;

                    break;
                }
            //Right-to-Left
            case 5:
                {
                    
                    //Mathf.CeilToInt(timer % 60);


                    if (selectWeapon >= 9)
                        shotAll = true;
                    else if (selectWeapon < 1)
                        shotAll = false;

                    SelectShots(selectWeapon);

                    if (shotAll == false)
                        selectWeapon++;
                    else
                        selectWeapon--;

                    

                    break;
                }
            case 6:
                {


                    if(shootInnerOuterCnt <= 5)
                    {
                        Instantiate(bullet4, spawnPoint4.position, spawnPoint4.rotation);
                        Instantiate(bullet5, spawnPoint5.position, spawnPoint5.rotation);
                        Instantiate(bullet6, spawnPoint6.position, spawnPoint6.rotation);

                        shootInnerOuterCnt++;
                    }

              

                    if (shootInnerOuterCnt >= 6 && shootInnerOuterCnt <= 10)
                    {
                        Instantiate(bullet1, spawnPoint1.position, spawnPoint1.rotation);
                        Instantiate(bullet2, spawnPoint2.position, spawnPoint2.rotation);
                        Instantiate(bullet3, spawnPoint3.position, spawnPoint3.rotation);
                        Instantiate(bullet7, spawnPoint7.position, spawnPoint7.rotation);
                        Instantiate(bullet8, spawnPoint8.position, spawnPoint8.rotation);
                        Instantiate(bullet9, spawnPoint9.position, spawnPoint9.rotation);
                        shootInnerOuterCnt++;
                    }

                    break;
                }

            default: 
                {
                    Instantiate(bullet1, spawnPoint1.position, spawnPoint1.rotation);
                    Instantiate(bullet2, spawnPoint2.position, spawnPoint2.rotation);
                    Instantiate(bullet3, spawnPoint3.position, spawnPoint3.rotation);
                    Instantiate(bullet4, spawnPoint4.position, spawnPoint4.rotation);
                    Instantiate(bullet5, spawnPoint5.position, spawnPoint5.rotation);
                    Instantiate(bullet6, spawnPoint6.position, spawnPoint6.rotation);
                    Instantiate(bullet7, spawnPoint7.position, spawnPoint7.rotation);
                    Instantiate(bullet8, spawnPoint8.position, spawnPoint8.rotation);
                    Instantiate(bullet9, spawnPoint9.position, spawnPoint9.rotation);
                    break;
                }
        };
    }

    private void SelectShots(int selectWeapon)
    {
        if (selectWeapon == 0)
        {
            Instantiate(bullet1, spawnPoint1.position, spawnPoint1.rotation);
        }
        else if (selectWeapon == 2)
        {
            Instantiate(bullet2, spawnPoint2.position, spawnPoint2.rotation);
        }
        else if (selectWeapon == 3)
        {
            Instantiate(bullet3, spawnPoint3.position, spawnPoint3.rotation);
        }
        else if (selectWeapon == 4)
        {
            Instantiate(bullet4, spawnPoint4.position, spawnPoint4.rotation);
        }
        else if (selectWeapon == 5)
        {
            Instantiate(bullet5, spawnPoint5.position, spawnPoint5.rotation);
        }
        else if (selectWeapon == 6)
        {
            Instantiate(bullet6, spawnPoint6.position, spawnPoint6.rotation);
        }
        else if (selectWeapon == 7)
        {
            Instantiate(bullet7, spawnPoint7.position, spawnPoint7.rotation);
        }
        else if (selectWeapon == 8)
        {
            Instantiate(bullet8, spawnPoint8.position, spawnPoint8.rotation);
        }
        else if (selectWeapon == 9)
        {
            Instantiate(bullet9, spawnPoint9.position, spawnPoint9.rotation);
        }

    }



}
