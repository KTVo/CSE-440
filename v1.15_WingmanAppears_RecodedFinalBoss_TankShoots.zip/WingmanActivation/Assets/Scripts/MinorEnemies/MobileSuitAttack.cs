﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MobileSuitAttack : MonoBehaviour
{
    private int countTriple = 0;
    public GameObject mobileBullet;
    public Transform spawnPointLeft;
    public Transform spawnPointMiddle;
    public Transform spawnPointRight;

    private float mobileSuitAttackCounter = 0.0f;
    private float mobileBurstTimer = 0.0f;
    // Start is called before the first frame update
    void Start()
    {
        mobileSuitAttackCounter = 0.0f;
        mobileBurstTimer = 0.0f;
        countTriple = 0;
    }

    // Update is called once per frame
    void Update()
    {
        mobileSuitAttackCounter += Time.deltaTime;

        if (mobileSuitAttackCounter > 1)
        {

            Instantiate(mobileBullet, spawnPointLeft.position, spawnPointLeft.rotation);
            Instantiate(mobileBullet, spawnPointMiddle.position, spawnPointMiddle.rotation);       
            Instantiate(mobileBullet, spawnPointRight.position, spawnPointRight.rotation);

            mobileSuitAttackCounter = 0.0f;
        }

        
    }
}
