﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FighterPivot : MonoBehaviour
{



    private Rigidbody2D rb;                                         // Used to apply forces with a 2D gameobject.


    //private Transform target;

    public Transform player;
 




    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
     

    }

    // Update is called once per frame
    void FixedUpdate()
    {

     
        Vector3 direction = player.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rb.rotation = angle;


     
    }
}