﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalBossTeleport : MonoBehaviour
{
    private Transform target;
    public GameObject[] position;

    Rigidbody2D rb;

    private float timerTelepeort;
    int rngSelectPosition;

    // Start is called before the first frame update
    void Start()
    {
        timerTelepeort = 0.0f;
        rb = this.GetComponent<Rigidbody2D>();
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();

        Vector3 direction = target.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rb.rotation = angle;

        timerTelepeort += Time.deltaTime;

        if (timerTelepeort > 3)
        {
            rngSelectPosition = Random.Range(0, 7);

            BossTeleport(rngSelectPosition);

            timerTelepeort = 0.0f;
        }
    }

    void BossTeleport(int pos)
    {
       
        gameObject.transform.position = new Vector2(position[pos].transform.position.x, position[pos].transform.position.y);
    }
}
