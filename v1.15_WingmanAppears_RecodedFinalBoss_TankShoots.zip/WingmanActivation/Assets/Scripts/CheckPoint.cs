﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class CheckPoint : MonoBehaviour
{
    private CheckPointManager checkPointMng;
   
    // Start is called before the first frame update
    void Start()
    {
        checkPointMng = GameObject.FindGameObjectWithTag("Player").GetComponent<CheckPointManager>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    

    //When checkpoint collides with another object
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.CompareTag("Player"))
        {
            checkPointMng.currentPosition = transform.position;
        }
    }
}
