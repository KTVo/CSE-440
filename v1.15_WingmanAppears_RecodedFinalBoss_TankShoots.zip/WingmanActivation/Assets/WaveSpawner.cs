﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveSpawner : MonoBehaviour
{
    public enum SpawnState { SPAWNING, WAITING, COUNTING };

    [System.Serializable]
    public class Wave
    {
        public string name;
        public Transform enemy1;
        public Transform enemy2;
        public Transform enemy3;
        public int count1;
        public int count2;
        public int count3;
        public float rate1;
        public float rate2;
        public float rate3;



    }
    public Wave[] waves;


    private int nextWave = 0;

    public Transform[] spawns;

    private float timeBetweenWaves = 4f;
    private float waveCountdown;
    public float timeInWave = 0f;
    private float startingSpawn = 1f;

    private float timeDelta = 10f;

    private float searchCountdown = 1f;

    public SpawnState state = SpawnState.COUNTING;



    void Start()
    {
        if (spawns.Length == 0)
        {
            Debug.LogError("No spawn available");
        }

        waveCountdown = timeBetweenWaves;
   
        

    }
    private void Update()
    {
        if (state == SpawnState.WAITING)
        {
            if (!EnemyIsAlive())
            {
                WaveCompleted();

            }

            else
            {
                Debug.Log("Wave is Active");
                return;
            }

        }



                if (waveCountdown <= 0)
                {//this will spawn our first wave of the game quicker than the other waves.
            if (startingSpawn == 1)
            {
                if (state != SpawnState.SPAWNING)
                {
                    //Spawn Wave

                    StartCoroutine(SpawnWave(waves[nextWave]));

                    timeInWave = 0f;

                    startingSpawn = 2;

                }
            }
                 timeInWave += Time.deltaTime;

                    if (timeInWave >= timeDelta)
                    {


                        DestroyWave();





                        if (state != SpawnState.SPAWNING)
                        {
                            //Spawn Wave

                            StartCoroutine(SpawnWave(waves[nextWave]));

                            timeInWave = 0f;
                            
                        }

                    }




                }
                waveCountdown -= Time.deltaTime;
               

                // check if the enemies are still alive
            
        

    }

    void WaveCompleted()
    {

        Debug.Log("Wave Completed!");


        state = SpawnState.COUNTING;
        waveCountdown = timeBetweenWaves;

        if(nextWave +1 > waves.Length -1)
        {
            Debug.Log("All Waves Completed! Moving On!");
           
            
        }
        else
        {
            nextWave++;

        }

    }
    bool EnemyIsAlive()
    {
        searchCountdown -= Time.deltaTime;
        if(searchCountdown <= 0f)
        {
            searchCountdown = 1f;
            if (GameObject.FindGameObjectsWithTag("Enemy") == null)
            {
                return false;
            }    
            
        }
        return true;

    }

 

    IEnumerator SpawnWave(Wave _wave)
    {
        Debug.Log("Spawning Wave: " + _wave.name);
        state = SpawnState.SPAWNING;
   
        if(_wave.name == "Boss")
        {
            timeDelta = 30f;
        }
        else
        {
            timeDelta = 10f;
        }


        for(int i = 0; i< _wave.count1; i++)
        {
            SpawnEnemy(_wave.enemy1);
             yield return new WaitForSeconds(1f / _wave.rate1);
        }
        for (int j = 0; j < _wave.count2; j++)
        {
            SpawnEnemy(_wave.enemy2);
            yield return new WaitForSeconds(1f / _wave.rate2);
        }
        for (int k = 0; k < _wave.count3; k++)
        {
            SpawnEnemy(_wave.enemy3);
            yield return new WaitForSeconds(1f / _wave.rate3);
        }

        state = SpawnState.WAITING;
        yield break;
    }

    void SpawnEnemy(Transform _enemy)
    {
        Debug.Log("Spawning Enemy: " + _enemy.name);



        Transform spawnPoint = spawns[Random.Range(0, spawns.Length)];
        Instantiate (_enemy, spawnPoint.position, spawnPoint.rotation);
        
    }
    void DestroyWave()
    {
        
        //this will find and destroy any game object tagged with "enemy"
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        Debug.Log("Destorying Enemies, Wave terminated");

        foreach (GameObject enemy in enemies)
        {
            Destroy(enemy);

            Debug.Log("Destroyed Enemies in Loop...");

        }
        
    }
}

